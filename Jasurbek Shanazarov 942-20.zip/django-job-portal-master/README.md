# django-job-portal
Job portal application using django
### Live : [Demo](https://job-portal-11.herokuapp.com/)
### DATABASE
#### Local : Sqlite
#### Live : postgresql

[![HitCount](http://hits.dwyl.com/{nazmul199512}/{django-job-portal}.svg)](http://hits.dwyl.com/{nazmul199512}/{django-job-portal})

## Screen Shots
<br/>
<br/>


![](ss1.png)
<br/>
![](ss2.png)
<br/>
![](ss3.png)
<br/>

<br/>


<br/>

![](ss6.png)<br/><br/>
<br/><br/>

<br/>

![](SS/ss05.png)

